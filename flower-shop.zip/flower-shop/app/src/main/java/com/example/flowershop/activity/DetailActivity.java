package com.example.flowershop.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.flowershop.R;
import com.example.flowershop.entity.Record;
import com.example.flowershop.entity.Stuff;
import com.example.flowershop.entity.User;
import com.example.flowershop.sqlite.BusinessResult;
import com.example.flowershop.sqlite.TableCart;
import com.example.flowershop.sqlite.TableRecord;
import com.example.flowershop.sqlite.TableStuff;
import com.example.flowershop.utils.CurrentUserUtils;

public class DetailActivity extends AppCompatActivity {

    private TextView tvName,tvInfo,tvPrice,tvCount,tvBuy,tvAdd;

    private ImageView ivImage, ivBack;

    private Stuff stuff;

    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Intent intent = getIntent();
        Integer stuffId = intent.getIntExtra("stuff_id", 0);
        stuff = TableStuff.getById(stuffId).getData();
        user = CurrentUserUtils.getCurrentUser();
        bindView();
        initView();
    }

    private void bindView() {
        tvName=findViewById(R.id.tv_name);
        tvInfo=findViewById(R.id.tv_info);
        tvPrice=findViewById(R.id.tv_price);
        tvCount=findViewById(R.id.tv_count);
        tvBuy=findViewById(R.id.tv_buy);
        tvAdd=findViewById(R.id.tv_add);
        ivImage=findViewById(R.id.iv_image);
        ivBack=findViewById(R.id.iv_back);
    }

    private void initView() {
        tvName.setText(stuff.getName());
        tvInfo.setText(stuff.getInfo());
        tvPrice.setText("价格：¥" + stuff.getPrice());
        tvCount.setText("库存：" + stuff.getCount());

        Glide.with(ivImage).load(stuff.getPic()).into(ivImage);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        tvAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BusinessResult<Void> result = TableCart.addCart(user.getId(), stuff.getId());
                Toast.makeText(DetailActivity.this, result.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        tvBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BusinessResult<Void> result=TableRecord.buy(stuff);
                Toast.makeText(DetailActivity.this, result.getMessage(), Toast.LENGTH_SHORT).show();
                if (result.isSuccess()) {
                    stuff.setCount(stuff.getCount() - 1);
                    tvCount.setText("库存：" + stuff.getCount());
                }
            }
        });
    }
}