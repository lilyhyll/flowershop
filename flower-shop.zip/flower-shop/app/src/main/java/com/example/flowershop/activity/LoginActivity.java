package com.example.flowershop.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.flowershop.R;
import com.example.flowershop.entity.User;
import com.example.flowershop.sqlite.BusinessResult;
import com.example.flowershop.sqlite.TableUser;
import com.example.flowershop.utils.CodeUtils;
import com.example.flowershop.utils.CurrentUserUtils;

public class LoginActivity extends AppCompatActivity {

    private TextView tvCode, tvRegister,tvLogin;

    private EditText etName, etPassword, etCode;

    private String code;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        bindView();
        initView();
    }


    private void bindView() {
        tvRegister = findViewById(R.id.tv_register);
        tvLogin = findViewById(R.id.tv_login);
        etPassword = findViewById(R.id.et_password);
        tvCode = findViewById(R.id.tv_code);
        etName = findViewById(R.id.et_name);
        etCode = findViewById(R.id.et_code);
    }

    private void initView() {
        User user = CurrentUserUtils.getCurrentUser();
        if (user!=null){
            etName.setText(user.getUsername());
        }

        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!etCode.getText().toString().equals(code)) {
                    Toast.makeText(LoginActivity.this, "验证码错误", Toast.LENGTH_SHORT).show();
                    return;
                }
                String username = etName.getText().toString();
                String password = etPassword.getText().toString();
                BusinessResult<User> result = TableUser.login(username, password);
                Toast.makeText(LoginActivity.this, result.getMessage(), Toast.LENGTH_SHORT).show();
                if (result.isSuccess()) {
                    CurrentUserUtils.setCurrentUser(result.getData());
                    Intent intent = new Intent();
                    intent.setClass(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
        code = CodeUtils.getCode();
        tvCode.setText(code);
    }
}