package com.example.flowershop.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.flowershop.R;
import com.example.flowershop.entity.User;
import com.example.flowershop.sqlite.BusinessResult;
import com.example.flowershop.sqlite.TableUser;


public class RegisterActivity extends AppCompatActivity {
    private ImageView ivBack;
    private EditText etName, etAddress;
    private EditText etPassword;
    private EditText etPasswordConfirm;
    private TextView tvRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        bindView();
        initView();
    }

    private void bindView() {
        etAddress = findViewById(R.id.et_address);
        ivBack = findViewById(R.id.iv_back);
        etName = findViewById(R.id.et_name);
        etPassword = findViewById(R.id.et_password);
        etPasswordConfirm = findViewById(R.id.et_password_confirm);
        tvRegister = findViewById(R.id.tv_register);
    }

    private void initView() {
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = new User();
                user.setUsername(etName.getText().toString());
                user.setPassword(etPassword.getText().toString());
                user.setAddress(etAddress.getText().toString());
                //注册
                BusinessResult<Void> result = TableUser.register(user, etPasswordConfirm.getText().toString());
                Toast.makeText(RegisterActivity.this, result.getMessage(), Toast.LENGTH_SHORT).show();
                if (result.isSuccess()) {
                    finish();
                }
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}