package com.example.flowershop.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.flowershop.R;
import com.example.flowershop.entity.Stuff;
import com.example.flowershop.sqlite.BusinessResult;
import com.example.flowershop.sqlite.TableStuff;
import com.example.flowershop.utils.AlbumUtils;

public class StuffEditActivity extends AppCompatActivity {

    private ImageView ivImg,ivBack;

    private TextView tvSelect, tvTitle,tvSubmit,tvDelete;

    private EditText etName,etInfo,etPrice,etCount;

    private Stuff stuff;

    private boolean isEdit = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stuff_edit);
        //绑定控件
        bindView();
        //初始化数据
        initData();
        //初始化控件
        initView();
    }

    private void bindView() {
        ivImg = findViewById(R.id.iv_img);
        ivBack = findViewById(R.id.iv_back);
        tvSelect = findViewById(R.id.tv_select);
        tvTitle = findViewById(R.id.tv_title);
        tvSubmit = findViewById(R.id.tv_submit);
        tvDelete = findViewById(R.id.tv_delete);
        etName = findViewById(R.id.et_name);
        etInfo = findViewById(R.id.et_info);
        etPrice = findViewById(R.id.et_price);
        etCount = findViewById(R.id.et_count);

    }

    private void initData() {
        stuff = (Stuff) getIntent().getSerializableExtra("stuff");
    }

    private void initView() {
        if (stuff != null) {
            tvTitle.setText("编辑商品");
            tvDelete.setVisibility(View.VISIBLE);
            tvDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(StuffEditActivity.this);
                    builder.setTitle("提示");
                    builder.setMessage("确定删除该商品吗？");
                    builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            BusinessResult<Void> result = TableStuff.deleteById(stuff.getId());
                            Toast.makeText(StuffEditActivity.this, result.getMessage(), Toast.LENGTH_SHORT).show();
                            if (result.isSuccess()) {
                                finish();
                            }
                        }
                    });
                    builder.setNegativeButton("取消", null);
                    builder.show();
                }
            });
            Glide.with(this).load(stuff.getPic()).into(ivImg);
            etName.setText(stuff.getName());
            etInfo.setText(stuff.getInfo());
            etPrice.setText(String.format("%.2f", stuff.getPrice()));
            etCount.setText(String.valueOf(stuff.getCount()));
            isEdit = true;
        } else {
            tvTitle.setText("添加商品");
            tvDelete.setVisibility(View.GONE);
            stuff = new Stuff();
            isEdit = false;
        }


        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        ivImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //选择图片
                AlbumUtils.openAlbum(StuffEditActivity.this);
            }
        });
        tvSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //选择图片
                AlbumUtils.openAlbum(StuffEditActivity.this);
            }
        });
        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stuff.setName(etName.getText().toString());
                stuff.setInfo(etInfo.getText().toString());
                String price = etPrice.getText().toString();
                if (TextUtils.isEmpty(price)) {
                    Toast.makeText(StuffEditActivity.this, "请输入价格", Toast.LENGTH_SHORT).show();
                    return;
                }
                String count = etCount.getText().toString();
                if (TextUtils.isEmpty(count)) {
                    Toast.makeText(StuffEditActivity.this, "请输入库存", Toast.LENGTH_SHORT).show();
                    return;
                }
                stuff.setPrice(Double.parseDouble(price));
                stuff.setCount(Integer.parseInt(count));
                BusinessResult<Void> result;
                if (isEdit) {
                    //编辑
                    result = TableStuff.update(stuff);
                } else {
                    //添加
                    result = TableStuff.add(stuff);
                }
                Toast.makeText(StuffEditActivity.this, result.getMessage(), Toast.LENGTH_SHORT).show();
                if (result.isSuccess()) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            //如果是打开相册，获取图片路径，显示图片
            if (requestCode == AlbumUtils.OPEN_ALBUM_REQUEST_CODE) {
                String path = AlbumUtils.getImagePath(data);
                Glide.with(this).load(path).into(ivImg);
                stuff.setPic(path);
            }
        }
    }
}
