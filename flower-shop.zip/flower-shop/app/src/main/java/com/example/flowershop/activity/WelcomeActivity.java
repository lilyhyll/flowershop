package com.example.flowershop.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.flowershop.R;
import com.example.flowershop.data.DataContent;
import com.hjq.permissions.OnPermissionCallback;
import com.hjq.permissions.Permission;
import com.hjq.permissions.XXPermissions;

import java.util.List;

public class WelcomeActivity extends AppCompatActivity {

    private TextView tvStart, tvManage;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        XXPermissions.with(this)
                .permission(Permission.WRITE_EXTERNAL_STORAGE)
                .permission(Permission.READ_MEDIA_IMAGES)
                .request(new OnPermissionCallback() {
                    @Override
                    public void onGranted(@NonNull List<String> permissions, boolean allGranted) {
                        //初始化数据
                        DataContent.init();
                    }
                });
        //绑定控件
        bindView();
        //初始化控件
        initView();
    }

    private void bindView() {
        tvStart = findViewById(R.id.tv_start);
        tvManage = findViewById(R.id.tv_manage);
    }

    private void initView() {
        //点击开始购物
        tvStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //跳转到用户登录页面
                Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        //点击管理商品
        tvManage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //跳转到管理页面
                Intent intent = new Intent(WelcomeActivity.this, ManageActivity.class);
                startActivity(intent);
            }
        });
    }
}
