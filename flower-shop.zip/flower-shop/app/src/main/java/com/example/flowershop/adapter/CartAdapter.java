package com.example.flowershop.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.example.flowershop.R;
import com.example.flowershop.entity.Stuff;

import java.util.ArrayList;
import java.util.List;

public class CartAdapter extends ArrayAdapter<Stuff> {

    private final List<Stuff> selectedStuffList = new ArrayList<>();

    private OnStuffSelectedListener onStuffSelectedListener;

    public CartAdapter(@NonNull Context context, int resource, @NonNull List<Stuff> objects) {
        super(context, resource, objects);
    }

    //每个子项被滚动到屏幕内的时候会被调用
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        Stuff item = getItem(position);//得到当前项的 Stuff 实例

        ViewHolder holder = ViewHolder.getViewHolder(convertView, parent);
        holder.tvName.setText(item.getName());
        holder.tvPrice.setText(String.format("¥%.2f", item.getPrice()));
        Glide.with(holder.ivPic).load(item.getPic()).into(holder.ivPic);

        holder.ivPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), item.getName(), Toast.LENGTH_SHORT).show();
            }
        });
        /*
        点击多选框，把此商品的价格加去或减去，显示在购物车页面的总价total中
        */
        holder.cbSelected.setChecked(false);
        holder.cbSelected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    selectedStuffList.add(item);
                } else {
                    selectedStuffList.remove(item);
                }
                if (onStuffSelectedListener != null) {
                    onStuffSelectedListener.onStuffSelected(selectedStuffList);
                }
            }
        });
        return holder.getView();
    }

    public void setData(List<Stuff> stuffList) {
        selectedStuffList.clear();
        clear();
        addAll(stuffList);
        notifyDataSetChanged();
    }

    public void setOnStuffSelectedListener(OnStuffSelectedListener onStuffSelectedListener) {
        this.onStuffSelectedListener = onStuffSelectedListener;
    }

    public List<Stuff> getSelectedStuffList() {
        return selectedStuffList;
    }

    public interface OnStuffSelectedListener {
        void onStuffSelected(List<Stuff> selectedStuffList);
    }

    public static class ViewHolder {

        private final View convertView;

        private final TextView tvName;
        private final TextView tvPrice;

        private final ImageView ivPic;

        private final CheckBox cbSelected;

        public ViewHolder(@Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
            }
            this.convertView = convertView;

            ivPic = convertView.findViewById(R.id.iv_pic);
            tvName = convertView.findViewById(R.id.tv_name);
            tvPrice = convertView.findViewById(R.id.tv_price);
            cbSelected = convertView.findViewById(R.id.cb_selected);

        }

        public static ViewHolder getViewHolder(@Nullable View convertView, @NonNull ViewGroup parent) {
            return new ViewHolder(convertView, parent);
        }

        public View getView() {
            return convertView;
        }

    }

}

