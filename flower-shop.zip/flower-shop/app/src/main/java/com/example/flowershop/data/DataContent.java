package com.example.flowershop.data;

import android.content.res.AssetManager;

import com.example.flowershop.R;
import com.example.flowershop.entity.Stuff;
import com.example.flowershop.sqlite.BusinessResult;
import com.example.flowershop.sqlite.TableStuff;
import com.example.flowershop.utils.ImagePreStorageUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class DataContent {
    /**
     * 注意！！
     * 注意！！
     * 注意！！
     * 当前数据编辑以后，需要卸载app，重新安装才能生效
     */
    public static void init(){
        // 初始化数据
        BusinessResult<List<Stuff>> result = TableStuff.selectAll();
        if (result.isSuccess() && !result.getData().isEmpty()) {
            return;
        }

        String stuffBmg = ImagePreStorageUtils.saveDrawableImage(R.drawable.stuff_bmg, "stuff_bmg");
        Stuff roseWhite = new Stuff("白玫瑰", "清新素雅的白色玫瑰，花瓣洁白如雪，散发着淡淡的清香", 28.99d, 99,stuffBmg);
        TableStuff.add(roseWhite);

        String stuffFmg = ImagePreStorageUtils.saveDrawableImage(R.drawable.stuff_fmg, "stuff_fmg");
        Stuff rosePink = new Stuff("粉玫瑰", "柔美粉色的玫瑰，娇艳欲滴，花语是甜蜜的爱情与温柔的关怀", 22.99d, 99,stuffFmg);
        TableStuff.add(rosePink);

        String stuffKnx = ImagePreStorageUtils.saveDrawableImage(R.drawable.stuff_knx, "stuff_knx");
        Stuff carnation = new Stuff("康乃馨", "康乃馨象征着母爱与关怀，花语是无尽的爱与感激，花瓣色彩丰富，芬芳宜人", 27.99d, 99,stuffKnx);
        TableStuff.add(carnation);

        String stuffLmg = ImagePreStorageUtils.saveDrawableImage(R.drawable.stuff_lmg, "stuff_lmg");
        Stuff roseBlue = new Stuff("蓝玫瑰", "神秘而罕见的蓝色玫瑰，象征着奇迹与梦想，独特的色彩令人心驰神往", 26.99d, 99,stuffLmg);
        TableStuff.add(roseBlue);

        String stuffXrk = ImagePreStorageUtils.saveDrawableImage(R.drawable.stuff_xrk, "stuff_xrk");
        Stuff sunflower = new Stuff("向日葵", "向日葵是太阳的化身，代表着希望与积极的生命力，金黄色的花朵给人温暖与活力", 30.99d, 99,stuffXrk);
        TableStuff.add(sunflower);

        String stuffYjx = ImagePreStorageUtils.saveDrawableImage(R.drawable.stuff_yjx, "stuff_yjx");
        Stuff tulip = new Stuff("郁金香", "郁金香是春天的使者，花语是美丽的爱情与真挚的情感，多姿多彩的花瓣散发着迷人的芳香", 21.99d, 99,stuffYjx);
        TableStuff.add(tulip);
    }

}
