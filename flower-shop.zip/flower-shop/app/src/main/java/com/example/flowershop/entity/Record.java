package com.example.flowershop.entity;

public class Record {

    private Integer id;

    private Integer userId;

    private Integer stuffId;

    /**
     * 商品名称
     */
    private String stuffName;

    /**
     * 商品价格
     */
    private Double stuffPrice;

    /**
     * 商品图片
     */
    private String stuffPic;

    /**
     * 用户地址
     */
    private String userAddress;


    public Record(Integer userId, String stuffName, Double stuffPrice,String stuffPic, String userAddress) {
        this.userId = userId;
        this.stuffName = stuffName;
        this.stuffPrice = stuffPrice;
        this.stuffPic = stuffPic;
        this.userAddress = userAddress;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStuffId() {
        return stuffId;
    }

    public void setStuffId(Integer stuffId) {
        this.stuffId = stuffId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getStuffName() {
        return stuffName;
    }

    public void setStuffName(String stuffName) {
        this.stuffName = stuffName;
    }

    public Double getStuffPrice() {
        return stuffPrice;
    }

    public void setStuffPrice(Double stuffPrice) {
        this.stuffPrice = stuffPrice;
    }

    public String getStuffPic() {
        return stuffPic;
    }

    public void setStuffPic(String stuffPic) {
        this.stuffPic = stuffPic;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }
}
