package com.example.flowershop.entity;

import java.io.Serializable;

public class Stuff implements Serializable {

    private Integer id;

    /**
     * 商品名称
     */
    private String name;

    /**
     * 商品介绍
     */
    private String info;

    /**
     * 商品价格
     */
    private Double price;

    /**
     * 商品数量
     */
    private Integer count;

    /**
     * 商品图片
     */
    private String pic;

    private Integer cartId;

    public Stuff() {
    }

    public Stuff(String name, String info, Double price, Integer count, String pic) {
        this.name = name;
        this.info = info;
        this.price = price;
        this.count = count;
        this.pic = pic;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }
}
