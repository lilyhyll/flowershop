package com.example.flowershop.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.flowershop.R;
import com.example.flowershop.adapter.CartAdapter;
import com.example.flowershop.entity.Stuff;
import com.example.flowershop.entity.User;
import com.example.flowershop.sqlite.BusinessResult;
import com.example.flowershop.sqlite.TableCart;
import com.example.flowershop.sqlite.TableRecord;
import com.example.flowershop.utils.CurrentUserUtils;

import java.util.List;


public class CartFragment extends Fragment {

    private TextView tvTotal;

    private ListView lvCart;

    private TextView etEmpty, tvBuy;

    private CartAdapter cartAdapter;

    private User user;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_cart, container, false);
        bindView(v);
        initData();
        initView();
        return v;
    }

    private void bindView(View v) {
        lvCart = v.findViewById(R.id.lv_cart);
        etEmpty = v.findViewById(R.id.tv_empty);
        tvTotal = v.findViewById(R.id.tv_total);
        tvBuy = v.findViewById(R.id.tv_buy);
    }

    private void initData() {
        user = CurrentUserUtils.getCurrentUser();
        List<Stuff> stuffList = TableCart.selectByUserId(user.getId()).getData();
        cartAdapter = new CartAdapter(getContext(), R.layout.item_cart, stuffList);
        cartAdapter.setOnStuffSelectedListener(new CartAdapter.OnStuffSelectedListener() {
            @Override
            public void onStuffSelected(List<Stuff> selectedStuffList) {
                double total = 0;
                for (Stuff stuff : selectedStuffList) {
                    total += stuff.getPrice();
                }
                tvTotal.setText(String.format("%.2f", total));
            }
        });
    }

    private void initView() {
        //获取购物车中商品
        if (cartAdapter.isEmpty()) {
            etEmpty.setVisibility(View.VISIBLE);
        } else {
            etEmpty.setVisibility(View.GONE);
        }
        lvCart.setAdapter(cartAdapter);

        //点击购买
        tvBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cartAdapter.getSelectedStuffList().size() == 0) {
                    Toast.makeText(getContext(), "你还未选择任何商品", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuilder error = new StringBuilder();
                double total = 0;
                for (Stuff stuff : cartAdapter.getSelectedStuffList()) {
                    BusinessResult<Void> result = TableRecord.buy(stuff);
                    if (!result.isSuccess()) {
                        //购买失败
                        error.append(stuff.getName()).append(result.getMessage()).append("\n");
                    } else {
                        total += stuff.getPrice();
                    }
                }
                List<Stuff> stuffList = TableCart.selectByUserId(user.getId()).getData();
                cartAdapter.setData(stuffList);
                String msg;
                if (total == 0) {
                    msg = error.toString().trim();
                } else {
                    msg = "价格总计" + String.format("%.2f", total) + "元，购买成功！\n" + error.toString().trim();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("提示");
                builder.setMessage(msg);
                builder.setPositiveButton("确定", null);
                builder.show();
                tvTotal.setText("0.00");
            }
        });
    }

}