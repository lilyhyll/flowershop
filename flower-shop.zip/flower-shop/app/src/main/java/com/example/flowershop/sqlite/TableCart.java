package com.example.flowershop.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;

import com.example.flowershop.entity.Stuff;
import com.example.flowershop.utils.SqliteUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("Range")
public class TableCart {

    /**
     * 添加购物车
     */
    public static BusinessResult<Void> addCart(Integer userId, Integer stuffId) {
        if (userId == null || stuffId == null) {
            return new BusinessResult<>(false, "用户ID或者商品ID不能为空", null);
        }
        BusinessResult<Void> isExistResult = isExist(userId, stuffId);
        if (isExistResult.isSuccess()) {
            return isExistResult;
        }
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("stuff_id", stuffId);
        long i = SqliteUtils.getInstance().getWritableDatabase().insert("_cart", null, values);
        if (i > 0) {
            return new BusinessResult<>(true, "添加成功", null);
        }
        return new BusinessResult<>(false, "添加失败", null);
    }

    /**
     * 是否存在
     */
    public static BusinessResult<Void> isExist(Integer userId, Integer stuffId) {
        if (userId == null || stuffId == null) {
            return new BusinessResult<>(false, "用户ID或者商品ID不能为空", null);
        }
        Cursor cursor = SqliteUtils.getInstance().getReadableDatabase().query("_cart", null, "user_id=? and stuff_id=?", new String[]{String.valueOf(userId), String.valueOf(stuffId)}, null, null, null);
        boolean isExist = cursor.moveToNext();
        cursor.close();
        if (isExist) {
            return new BusinessResult<>(true, "加入购物车失败，或已在购物车中", null);
        }else{
            return new BusinessResult<>(false, "加入购物车成功", null);
        }
    }

    /**
     * 根据购物车id删除
     */
    public static BusinessResult<Void> deleteById(Integer id) {
        if (id == null) {
            return new BusinessResult<>(false, "数据不能为空", null);
        }
        SqliteUtils.getInstance().getWritableDatabase().delete("_cart", "_id=?", new String[]{String.valueOf(id)});
        return new BusinessResult<>(true, "删除成功", null);
    }

    /**
     * 根据用户id查询
     */
    public static BusinessResult<List<Stuff>> selectByUserId(Integer userId) {
        if (userId == null) {
            return new BusinessResult<>(false, "用户ID不能为空", null);
        }
        List<Stuff> stuffList = new ArrayList<>();
        List<Integer> errorCartIdList = new ArrayList<>();
        //根据id倒序查询
        Cursor cursor = SqliteUtils.getInstance().getReadableDatabase().query("_cart", null, "user_id=?", new String[]{String.valueOf(userId)}, null, null, "_id desc");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            Integer stuffId = cursor.getInt(cursor.getColumnIndex("stuff_id"));
            BusinessResult<Stuff> getByIdResult = TableStuff.getById(stuffId);
            if (getByIdResult.isSuccess()) {
                Stuff data = getByIdResult.getData();
                data.setCartId(id);
                stuffList.add(data);
            }else{
                errorCartIdList.add(id);
            }
        }
        cursor.close();
        if (!errorCartIdList.isEmpty()) {
            for (Integer errorCartId : errorCartIdList) {
                deleteById(errorCartId);
            }
        }
        return new BusinessResult<>(true, "查询成功", stuffList);
    }

}
