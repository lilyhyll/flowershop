package com.example.flowershop.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.example.flowershop.activity.DetailActivity;
import com.example.flowershop.entity.Record;
import com.example.flowershop.entity.Stuff;
import com.example.flowershop.entity.User;
import com.example.flowershop.utils.CurrentUserUtils;
import com.example.flowershop.utils.SqliteUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("Range")
public class TableRecord {
    /**
     * 购买商品，添加记录
     */
    public static BusinessResult<Void> buy(Stuff stuff) {
        if (stuff == null) {
            return new BusinessResult<>(false, "数据不能为空", null);
        }
        User currentUser = CurrentUserUtils.getCurrentUser();
        if (currentUser == null) {
            return new BusinessResult<>(false, "请先登录", null);
        }
        Integer stuffId = stuff.getId();
        Integer cartId = stuff.getCartId();

        BusinessResult<Stuff> result = TableStuff.getById(stuffId);
        if (!result.isSuccess()) {
            return new BusinessResult<>(false, result.getMessage(), null);
        }
        stuff = result.getData();
        Integer count = stuff.getCount();
        if (count == 0) {
            return new BusinessResult<>(false, "库存不足", null);
        }
        stuff.setCount(count - 1);
        BusinessResult<Void> update = TableStuff.update(stuff);
        if (!update.isSuccess()) {
            return new BusinessResult<>(false, "购买失败", null);
        }
        ContentValues values = new ContentValues();
        values.put("user_id", currentUser.getId());
        values.put("stuff_name", stuff.getName());
        values.put("stuff_price", stuff.getPrice());
        values.put("stuff_pic", stuff.getPic());
        values.put("user_address", currentUser.getAddress());
        long i = SqliteUtils.getInstance().getWritableDatabase().insert("_record", null, values);
        if (i > 0) {
            if (cartId!=null && !TableCart.deleteById(cartId).isSuccess()) {
                return new BusinessResult<>(false, "购买失败", null);
            }
            return new BusinessResult<>(true, String.format("价格%.2f元，购买成功！",stuff.getPrice()), null);
        } else {
            return new BusinessResult<>(false, "购买失败", null);
        }
    }

    /**
     * 根据用户ID获取记录
     */
    public static BusinessResult<List<Record>> selectByUserId(Integer userId) {
        if (userId == null) {
            return new BusinessResult<>(false, "用户ID不能为空", null);
        }
        List<Record> list = new ArrayList<>();
        Cursor cursor = SqliteUtils.getInstance().getReadableDatabase().query("_record", null, "user_id=?", new String[]{String.valueOf(userId)}, null, null, null);
        while (cursor.moveToNext()) {
            Integer id = cursor.getInt(cursor.getColumnIndex("_id"));
            String stuffName = cursor.getString(cursor.getColumnIndex("stuff_name"));
            Double stuffPrice = cursor.getDouble(cursor.getColumnIndex("stuff_price"));
            String stuffPic = cursor.getString(cursor.getColumnIndex("stuff_pic"));
            String userAddress = cursor.getString(cursor.getColumnIndex("user_address"));
            Record record = new Record(userId, stuffName, stuffPrice,stuffPic, userAddress);
            record.setId(id);
            list.add(record);
        }
        return new BusinessResult<>(true, "查询成功", list);
    }

}

