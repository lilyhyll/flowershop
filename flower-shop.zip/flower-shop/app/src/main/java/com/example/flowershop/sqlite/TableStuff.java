package com.example.flowershop.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.text.TextUtils;
import android.util.Log;

import com.example.flowershop.entity.Stuff;
import com.example.flowershop.utils.SqliteUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("Range")
public class TableStuff {

    public static BusinessResult<Void> add(Stuff stuff) {
        if (stuff == null) {
            return new BusinessResult<>(false, "数据不能为空", null);
        }
        if (TextUtils.isEmpty(stuff.getName())) {
            return new BusinessResult<>(false, "商品名称不能为空", null);
        }
        if (TextUtils.isEmpty(stuff.getInfo())) {
            return new BusinessResult<>(false, "商品介绍不能为空", null);
        }
        if (stuff.getPrice() == null) {
            return new BusinessResult<>(false, "商品价格不能为空", null);
        }
        if (stuff.getCount() == null) {
            return new BusinessResult<>(false, "商品数量不能为空", null);
        }
        if (TextUtils.isEmpty(stuff.getPic())) {
            return new BusinessResult<>(false, "商品图片不能为空", null);
        }
        ContentValues values = new ContentValues();
        values.put("name", stuff.getName());
        values.put("info", stuff.getInfo());
        values.put("price", stuff.getPrice());
        values.put("count", stuff.getCount());
        values.put("pic", stuff.getPic());
        long i = SqliteUtils.getInstance().getWritableDatabase().insert("_stuff", null, values);
        if (i > 0) {
            return new BusinessResult<>(true, "添加成功", null);
        }
        return new BusinessResult<>(false, "添加失败", null);
    }

    /**
     * 修改商品信息
     */
    public static BusinessResult<Void> update(Stuff stuff) {
        if (stuff == null) {
            return new BusinessResult<>(false, "数据不能为空", null);
        }
        if (stuff.getId() == null) {
            return new BusinessResult<>(false, "商品id不能为空", null);
        }
        if (TextUtils.isEmpty(stuff.getName())) {
            return new BusinessResult<>(false, "商品名称不能为空", null);
        }
        if (TextUtils.isEmpty(stuff.getInfo())) {
            return new BusinessResult<>(false, "商品介绍不能为空", null);
        }
        if (stuff.getPrice() == null) {
            return new BusinessResult<>(false, "商品价格不能为空", null);
        }
        if (stuff.getCount() == null) {
            return new BusinessResult<>(false, "商品数量不能为空", null);
        }
        if (TextUtils.isEmpty(stuff.getPic())) {
            return new BusinessResult<>(false, "商品图片不能为空", null);
        }
        ContentValues values = new ContentValues();
        values.put("name", stuff.getName());
        values.put("info", stuff.getInfo());
        values.put("price", stuff.getPrice());
        values.put("count", stuff.getCount());
        values.put("pic", stuff.getPic());
        long i = SqliteUtils.getInstance().getWritableDatabase().update("_stuff", values, "_id=?", new String[]{String.valueOf(stuff.getId())});
        if (i > 0) {
            return new BusinessResult<>(true, "修改成功", null);
        }
        return new BusinessResult<>(false, "修改失败", null);
    }

    /**
     * 根据商品id删除商品
     */
    public static BusinessResult<Void> deleteById(int id) {
        long i = SqliteUtils.getInstance().getWritableDatabase().delete("_stuff", "_id=?", new String[]{String.valueOf(id)});
        if (i > 0) {
            return new BusinessResult<>(true, "删除成功", null);
        }
        return new BusinessResult<>(false, "删除失败", null);
    }

    /**
     * 查询所有商品
     */
    public static BusinessResult<List<Stuff>> selectAll() {
        List<Stuff> list = new ArrayList<>();
        //根据商品id降序查询
        Cursor cursor = SqliteUtils.getInstance().getReadableDatabase().query("_stuff", null, null, null, null, null, "_id desc");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String info = cursor.getString(cursor.getColumnIndex("info"));
            double price = cursor.getDouble(cursor.getColumnIndex("price"));
            int count = cursor.getInt(cursor.getColumnIndex("count"));
            String pic = cursor.getString(cursor.getColumnIndex("pic"));
            Stuff stuff = new Stuff(name, info, price, count, pic);
            stuff.setId(id);
            list.add(stuff);
        }
        return new BusinessResult<>(true, "查询成功", list);
    }

    /**
     * 根据商品名称查询
     */
    public static BusinessResult<List<Stuff>> selectByName(String name) {
        if (TextUtils.isEmpty(name)) {
            return new BusinessResult<>(false, "商品名称不能为空", null);
        }
        List<Stuff> list = new ArrayList<>();
        //根据商品名称模糊查询,查询结果按商品id降序排列
        Cursor cursor = SqliteUtils.getInstance().getReadableDatabase().query("_stuff", null, "name like ?", new String[]{"%" + name + "%"}, null, null, "_id desc");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            String stuffName = cursor.getString(cursor.getColumnIndex("name"));
            String info = cursor.getString(cursor.getColumnIndex("info"));
            double price = cursor.getDouble(cursor.getColumnIndex("price"));
            int count = cursor.getInt(cursor.getColumnIndex("count"));
            String pic = cursor.getString(cursor.getColumnIndex("pic"));
            Stuff stuff = new Stuff(name, info, price, count, pic);
            stuff.setId(id);
            list.add(stuff);
        }
        return new BusinessResult<>(true, "查询成功", list);
    }

    /**
     * 根据商品id查询商品
     */
    public static BusinessResult<Stuff> getById(Integer stuffId){
        if (stuffId == null) {
            return new BusinessResult<>(false, "商品id不能为空", null);
        }
        Cursor cursor = SqliteUtils.getInstance().getReadableDatabase().query("_stuff", null, "_id=?", new String[]{String.valueOf(stuffId)}, null, null, null);
        if (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String info = cursor.getString(cursor.getColumnIndex("info"));
            double price = cursor.getDouble(cursor.getColumnIndex("price"));
            int count = cursor.getInt(cursor.getColumnIndex("count"));
            String pic = cursor.getString(cursor.getColumnIndex("pic"));
            Stuff stuff = new Stuff(name, info, price, count, pic);
            stuff.setId(id);
            return new BusinessResult<>(true, "查询成功", stuff);
        }
        return new BusinessResult<>(false, "商品不存在", null);
    }

}

