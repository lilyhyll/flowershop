package com.example.flowershop.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.text.TextUtils;
import android.util.Log;

import com.example.flowershop.entity.User;
import com.example.flowershop.utils.SqliteUtils;

@SuppressLint("Range")
public class TableUser {

    public static BusinessResult<Void> register(User user, String confirmPassword) {
        if (user == null|| TextUtils.isEmpty(user.getUsername())|| TextUtils.isEmpty(user.getPassword())|| TextUtils.isEmpty(user.getAddress())|| TextUtils.isEmpty(confirmPassword)) {
            return new BusinessResult<>(false, "数据不能为空", null);
        }
        if (!user.getPassword().equals(confirmPassword)) {
            return new BusinessResult<>(false, "两次密码不一样", null);
        }

        BusinessResult<User> getByUsernameResult = getByUsername(user.getUsername());
        if (getByUsernameResult.isSuccess()) {
            return new BusinessResult<>(false, "用户名已存在", null);
        }

        ContentValues values = new ContentValues();
        values.put("username", user.getUsername());
        values.put("password", user.getPassword());
        values.put("address", user.getAddress());
        long i = SqliteUtils.getInstance().getWritableDatabase().insert("_user", null, values);
        if (i > 0) {
            return new BusinessResult<>(true, "注册成功", null);
        }
        return new BusinessResult<>(false, "注册失败", null);
    }

    /**
     * 修改收货地址
     */
    public static BusinessResult<Void> changeAddress(Integer userId,String address){
        if (userId == null|| TextUtils.isEmpty(address)) {
            return new BusinessResult<>(false, "数据不能为空", null);
        }
        ContentValues values = new ContentValues();
        values.put("address", address);
        long i = SqliteUtils.getInstance().getWritableDatabase().update("_user", values, "_id=?", new String[]{String.valueOf(userId)});
        if (i > 0) {
            return new BusinessResult<>(true, "修改成功", null);
        }
        return new BusinessResult<>(false, "修改失败", null);
    }

    /**
     * 登录
     */
    public static BusinessResult<User> login(String username, String password) {
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            return new BusinessResult<>(false, "用户名或密码不能为空", null);
        }
        Cursor cursor = SqliteUtils.getInstance().getReadableDatabase().query("_user", null, "username=? and password=?", new String[]{username, password}, null, null, null);
        if (cursor.moveToNext()) {
            User user = new User();
            user.setId(cursor.getInt(cursor.getColumnIndex("_id")));
            user.setUsername(cursor.getString(cursor.getColumnIndex("username")));
            user.setAddress(cursor.getString(cursor.getColumnIndex("address")));
            return new BusinessResult<>(true, "登录成功", user);
        }
        cursor.close();
        return new BusinessResult<>(false, "用户名或密码错误", null);
    }

    /**
     * 根据用户名查询用户
     */
    public static BusinessResult<User> getByUsername(String username) {
        if (TextUtils.isEmpty(username)) {
            return new BusinessResult<>(false, "用户名不能为空", null);
        }
        Cursor cursor = SqliteUtils.getInstance().getReadableDatabase().query("_user", null, "username=?", new String[]{username}, null, null, null);
        if (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            String name = cursor.getString(cursor.getColumnIndex("username"));
            String password = cursor.getString(cursor.getColumnIndex("password"));
            User user = new User();
            user.setId(id);
            user.setUsername(name);
            user.setPassword(password);
            return new BusinessResult<>(true, "查询成功", user);
        }
        cursor.close();
        return new BusinessResult<>(false, "用户不存在", null);
    }
}
