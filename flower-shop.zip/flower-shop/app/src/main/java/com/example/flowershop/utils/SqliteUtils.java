package com.example.flowershop.utils;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SqliteUtils extends SQLiteOpenHelper {

    public SqliteUtils() {
        super(AppUtils.getApplication(), "flower_shop.db", null, 1);
    }

    /**
     * 创建并获取单例
     */
    public static SqliteUtils getInstance() {
        return InstanceHolder.instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        /*
        用户表(_user)：
        _id       integer  用户id
        username  varchar  用户名
        password  varchar  密码
        address   varchar  地址
         */
        db.execSQL("CREATE TABLE _user(_id INTEGER PRIMARY KEY AUTOINCREMENT,username VARCHAR(20) ,password VARCHAR(20),address VARCHAR(50))");
        /*
        商品表(_stuff)：
        _id          integer  商品id
        name         varchar  商品名称
        info         varchar  商品介绍
        price        real     商品价格
        count        integer  商品数量
        pic          varchar  商品图片
         */
        db.execSQL("CREATE TABLE _stuff(_id INTEGER PRIMARY KEY AUTOINCREMENT,name VARCHAR(20),info VARCHAR(200),price REAL,count INTEGER,pic VARCHAR(200))");
        /*
        订单表(_record)：
        _id          integer  订单id
        user_id      integer  用户id
        stuff_name   varchar  商品名称
        stuff_price  real     商品价格
        stuff_pic    varchar  商品图片
        user_address varchar  用户地址
         */
        db.execSQL("CREATE TABLE _record(_id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,stuff_name VARCHAR(20),stuff_price REAL,stuff_pic VARCHAR(200),user_address VARCHAR(50))");
        /*
        购物车表(_cart)：
        _id          integer  购物车id
        user_id      integer  用户id
        stuff_id     integer  商品id
         */
        db.execSQL("CREATE TABLE _cart(_id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,stuff_id INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        //删除表
        db.execSQL("DROP TABLE IF EXISTS _user");
        db.execSQL("DROP TABLE IF EXISTS _stuff");
        db.execSQL("DROP TABLE IF EXISTS _record");
        db.execSQL("DROP TABLE IF EXISTS _cart");
        //重新创建表
        onCreate(db);
    }

    private static final class InstanceHolder {
        /**
         * 单例
         */
        static final SqliteUtils instance = new SqliteUtils();
    }

}
